package com.example.receiving_address.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.receiving_address.pojo.ReceivingAddress;


public interface ReAddressDao extends BaseMapper<ReceivingAddress> {


}
