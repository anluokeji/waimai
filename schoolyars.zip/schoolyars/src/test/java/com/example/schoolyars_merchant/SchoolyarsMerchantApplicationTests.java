package com.example.schoolyars_merchant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolyarsMerchantApplicationTests {

    @Test
    void contextLoads() {
    }

}
